import { useState, useEffect } from 'react';
import { Scan, AlertTriangle, Shield, HardDrive, Activity, Zap } from 'lucide-react';
import { MainLayout } from '@/components/layout/MainLayout';
import { StatsCard } from '@/components/dashboard/StatsCard';
import { ThreatChart } from '@/components/dashboard/ThreatChart';
import { SystemHealth } from '@/components/dashboard/SystemHealth';
import { RecentThreats } from '@/components/dashboard/RecentThreats';
import { formatBytes } from '@/lib/formatters';
import { ThreatStats, RiskDistribution, HealthStatus, ThreatLog, RiskLevel, SourceType } from '@/types';

// Mock data for demo
const mockStats: ThreatStats = {
  total: 15847,
  critical: 23,
  high: 156,
  medium: 892,
  low: 2341,
  benign: 12435,
  total_bytes_scanned: 5847293847,
};

const mockDistribution: RiskDistribution = {
  BENIGN: 12435,
  LOW: 2341,
  MEDIUM: 892,
  HIGH: 156,
  CRITICAL: 23,
};

const mockHealth: HealthStatus = {
  status: 'healthy',
  model: {
    loaded: true,
    model_path: '/models/malware_detector_v2.pt',
    device: 'CUDA (RTX 4090)',
    parameters: 125000000,
    vocab_size: 50257,
    d_model: 768,
    num_layers: 12,
  },
  database: {
    connected: true,
    path: 'postgresql://localhost:5432/malware_db',
    total_threats: 15847,
  },
  uptime_seconds: 847293,
  memory_usage_mb: 4892,
  timestamp: new Date().toISOString(),
};

const mockRecentThreats: ThreatLog[] = [
  {
    id: 1,
    source: 'https://malicious-site.example.com/payload.exe',
    source_type: SourceType.URL,
    probability: 0.97,
    bytes_scanned: 2457832,
    risk_level: RiskLevel.CRITICAL,
    timestamp: new Date(Date.now() - 300000).toISOString(),
    blocked: true,
  },
  {
    id: 2,
    source: 'suspicious_document.pdf',
    source_type: SourceType.FILE,
    probability: 0.84,
    bytes_scanned: 1892374,
    risk_level: RiskLevel.HIGH,
    timestamp: new Date(Date.now() - 900000).toISOString(),
    blocked: true,
  },
  {
    id: 3,
    source: 'https://download.example.org/installer.msi',
    source_type: SourceType.URL,
    probability: 0.62,
    bytes_scanned: 45872934,
    risk_level: RiskLevel.MEDIUM,
    timestamp: new Date(Date.now() - 1800000).toISOString(),
    blocked: false,
  },
  {
    id: 4,
    source: 'email_attachment.docx',
    source_type: SourceType.FILE,
    probability: 0.38,
    bytes_scanned: 384729,
    risk_level: RiskLevel.LOW,
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    blocked: false,
  },
];

export default function Dashboard() {
  return (
    <MainLayout
      title="Dashboard"
      subtitle="Real-time malware detection overview"
    >
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatsCard
          title="Total Scans"
          value={mockStats.total.toLocaleString()}
          subtitle="All time"
          icon={Scan}
          trend={{ value: 12.5, isPositive: true }}
        />
        <StatsCard
          title="Critical Threats"
          value={mockStats.critical}
          subtitle="Immediate action required"
          icon={AlertTriangle}
          variant="danger"
          trend={{ value: 3, isPositive: false }}
        />
        <StatsCard
          title="High Threats"
          value={mockStats.high}
          subtitle="Blocked automatically"
          icon={Shield}
          variant="warning"
        />
        <StatsCard
          title="Data Scanned"
          value={formatBytes(mockStats.total_bytes_scanned)}
          subtitle="Total bytes analyzed"
          icon={HardDrive}
          variant="success"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <ThreatChart data={mockDistribution} />
        <SystemHealth health={mockHealth} />
      </div>

      {/* Recent Threats */}
      <RecentThreats threats={mockRecentThreats} />
    </MainLayout>
  );
}
