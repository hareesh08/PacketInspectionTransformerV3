import Dashboard from './Dashboard';

// Re-export Dashboard as the Index page
export default Dashboard;
