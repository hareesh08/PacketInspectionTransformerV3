import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { UrlScanner } from '@/components/scanner/UrlScanner';
import { FileUploader } from '@/components/scanner/FileUploader';
import { ScanResult as ScanResultComponent } from '@/components/scanner/ScanResult';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Globe, FileText, History, Trash2 } from 'lucide-react';
import { ScanResult, RiskLevel, SourceType, ScanStatus } from '@/types';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { formatRelativeTime, getRiskColorClass } from '@/lib/formatters';
import { Badge } from '@/components/ui/badge';

export default function Scanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [currentResult, setCurrentResult] = useState<ScanResult | null>(null);
  const [scanHistory, setScanHistory] = useState<ScanResult[]>([]);

  const handleUrlScan = async (url: string, blockOnDetection: boolean) => {
    setIsScanning(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Generate mock result
    const probability = Math.random();
    const riskLevel =
      probability < 0.2
        ? RiskLevel.BENIGN
        : probability < 0.4
        ? RiskLevel.LOW
        : probability < 0.6
        ? RiskLevel.MEDIUM
        : probability < 0.8
        ? RiskLevel.HIGH
        : RiskLevel.CRITICAL;

    const result: ScanResult = {
      source: url,
      source_type: SourceType.URL,
      probability,
      risk_level: riskLevel,
      bytes_scanned: Math.floor(Math.random() * 10000000),
      blocked: blockOnDetection && probability > 0.7,
      scan_time_ms: Math.floor(Math.random() * 500) + 100,
      status: probability > 0.5 ? ScanStatus.THREAT_DETECTED : ScanStatus.CLEAN,
      timestamp: new Date().toISOString(),
    };

    setCurrentResult(result);
    setScanHistory((prev) => [result, ...prev.slice(0, 9)]);
    setIsScanning(false);
  };

  const handleFileUpload = async (file: File, blockOnDetection: boolean) => {
    setIsScanning(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 3000));

    // Generate mock result
    const probability = Math.random();
    const riskLevel =
      probability < 0.3
        ? RiskLevel.BENIGN
        : probability < 0.5
        ? RiskLevel.LOW
        : probability < 0.7
        ? RiskLevel.MEDIUM
        : probability < 0.85
        ? RiskLevel.HIGH
        : RiskLevel.CRITICAL;

    const result: ScanResult = {
      source: file.name,
      source_type: SourceType.FILE,
      probability,
      risk_level: riskLevel,
      bytes_scanned: file.size,
      blocked: blockOnDetection && probability > 0.7,
      scan_time_ms: Math.floor(Math.random() * 1000) + 200,
      status: probability > 0.5 ? ScanStatus.THREAT_DETECTED : ScanStatus.CLEAN,
      timestamp: new Date().toISOString(),
    };

    setCurrentResult(result);
    setScanHistory((prev) => [result, ...prev.slice(0, 9)]);
    setIsScanning(false);
  };

  const clearHistory = () => {
    setScanHistory([]);
    setCurrentResult(null);
  };

  return (
    <MainLayout
      title="Malware Scanner"
      subtitle="Scan URLs and files for malicious content"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scanner tabs */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="url" className="space-y-4">
            <TabsList className="grid w-full grid-cols-2 bg-secondary">
              <TabsTrigger value="url" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <Globe className="h-4 w-4 mr-2" />
                URL Scanner
              </TabsTrigger>
              <TabsTrigger value="file" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <FileText className="h-4 w-4 mr-2" />
                File Scanner
              </TabsTrigger>
            </TabsList>

            <TabsContent value="url">
              <UrlScanner onScan={handleUrlScan} isScanning={isScanning} />
            </TabsContent>

            <TabsContent value="file">
              <FileUploader onUpload={handleFileUpload} isScanning={isScanning} />
            </TabsContent>
          </Tabs>

          {/* Current result */}
          {currentResult && (
            <div className="mt-6">
              <ScanResultComponent result={currentResult} />
            </div>
          )}
        </div>

        {/* Scan history */}
        <div className="lg:col-span-1">
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                <h3 className="text-lg font-semibold text-foreground">Scan History</h3>
              </div>
              {scanHistory.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearHistory}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>

            {scanHistory.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <History className="h-8 w-8 text-muted-foreground/50 mb-2" />
                <p className="text-sm text-muted-foreground">No scans yet</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Scan a URL or file to see results here
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {scanHistory.map((result, index) => (
                  <div
                    key={index}
                    className={cn(
                      'flex items-center gap-3 rounded-lg bg-secondary/50 px-3 py-2 cursor-pointer transition-colors hover:bg-secondary',
                      currentResult === result && 'ring-1 ring-primary'
                    )}
                    onClick={() => setCurrentResult(result)}
                  >
                    {result.source_type === SourceType.URL ? (
                      <Globe className="h-4 w-4 shrink-0 text-muted-foreground" />
                    ) : (
                      <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="truncate text-sm font-mono">{result.source}</div>
                      <div className="text-xs text-muted-foreground">
                        {formatRelativeTime(result.timestamp)}
                      </div>
                    </div>
                    <Badge
                      variant="outline"
                      className={cn('shrink-0 border text-xs', getRiskColorClass(result.risk_level))}
                    >
                      {result.risk_level}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
