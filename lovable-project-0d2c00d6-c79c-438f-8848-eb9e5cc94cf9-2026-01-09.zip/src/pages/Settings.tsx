import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { ThresholdSlider } from '@/components/settings/ThresholdSlider';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Settings as SettingsIcon, Save, Shield, Bell, Database, Loader2, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function Settings() {
  const [threshold, setThreshold] = useState(0.7);
  const [isSaving, setIsSaving] = useState(false);
  const [notifications, setNotifications] = useState({
    criticalAlerts: true,
    highAlerts: true,
    mediumAlerts: false,
    dailyReport: true,
  });
  const [config, setConfig] = useState({
    chunkSize: 4096,
    windowSize: 512,
    autoBlock: true,
    logRetention: 30,
  });

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsSaving(false);
    toast.success('Settings saved successfully', {
      description: 'Your configuration has been updated.',
    });
  };

  return (
    <MainLayout
      title="Settings"
      subtitle="Configure detection parameters and preferences"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Detection Threshold */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-foreground">Detection Threshold</CardTitle>
                <CardDescription>
                  Adjust sensitivity of the malware detection engine
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <ThresholdSlider
              value={threshold}
              onChange={setThreshold}
              disabled={isSaving}
            />
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Bell className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-foreground">Notifications</CardTitle>
                <CardDescription>
                  Configure alert preferences
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-foreground">Critical Alerts</Label>
                <p className="text-xs text-muted-foreground">
                  Immediate notification for critical threats
                </p>
              </div>
              <Switch
                checked={notifications.criticalAlerts}
                onCheckedChange={(checked) =>
                  setNotifications((prev) => ({ ...prev, criticalAlerts: checked }))
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-foreground">High Risk Alerts</Label>
                <p className="text-xs text-muted-foreground">
                  Notify when high-risk threats are detected
                </p>
              </div>
              <Switch
                checked={notifications.highAlerts}
                onCheckedChange={(checked) =>
                  setNotifications((prev) => ({ ...prev, highAlerts: checked }))
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-foreground">Medium Risk Alerts</Label>
                <p className="text-xs text-muted-foreground">
                  Notify for medium-risk threats
                </p>
              </div>
              <Switch
                checked={notifications.mediumAlerts}
                onCheckedChange={(checked) =>
                  setNotifications((prev) => ({ ...prev, mediumAlerts: checked }))
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-foreground">Daily Report</Label>
                <p className="text-xs text-muted-foreground">
                  Receive daily threat summary via email
                </p>
              </div>
              <Switch
                checked={notifications.dailyReport}
                onCheckedChange={(checked) =>
                  setNotifications((prev) => ({ ...prev, dailyReport: checked }))
                }
              />
            </div>
          </CardContent>
        </Card>

        {/* System Configuration */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <SettingsIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-foreground">System Configuration</CardTitle>
                <CardDescription>
                  Advanced engine parameters
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="chunkSize" className="text-foreground">Chunk Size</Label>
                <Input
                  id="chunkSize"
                  type="number"
                  value={config.chunkSize}
                  onChange={(e) =>
                    setConfig((prev) => ({ ...prev, chunkSize: parseInt(e.target.value) }))
                  }
                  className="bg-secondary border-border"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="windowSize" className="text-foreground">Window Size</Label>
                <Input
                  id="windowSize"
                  type="number"
                  value={config.windowSize}
                  onChange={(e) =>
                    setConfig((prev) => ({ ...prev, windowSize: parseInt(e.target.value) }))
                  }
                  className="bg-secondary border-border"
                />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-foreground">Auto-Block Threats</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically block high-risk content
                </p>
              </div>
              <Switch
                checked={config.autoBlock}
                onCheckedChange={(checked) =>
                  setConfig((prev) => ({ ...prev, autoBlock: checked }))
                }
              />
            </div>
          </CardContent>
        </Card>

        {/* Data Management */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Database className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-foreground">Data Management</CardTitle>
                <CardDescription>
                  Configure data retention and storage
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="retention" className="text-foreground">Log Retention (days)</Label>
              <Input
                id="retention"
                type="number"
                value={config.logRetention}
                onChange={(e) =>
                  setConfig((prev) => ({ ...prev, logRetention: parseInt(e.target.value) }))
                }
                className="bg-secondary border-border"
              />
              <p className="text-xs text-muted-foreground">
                Threat logs older than this will be automatically archived
              </p>
            </div>
            <div className="rounded-lg bg-secondary/50 p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Database Size</span>
                <span className="font-mono text-foreground">2.4 GB</span>
              </div>
              <div className="flex items-center justify-between text-sm mt-2">
                <span className="text-muted-foreground">Total Records</span>
                <span className="font-mono text-foreground">15,847</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Save button */}
      <div className="mt-6 flex justify-end">
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          {isSaving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </>
          )}
        </Button>
      </div>
    </MainLayout>
  );
}
