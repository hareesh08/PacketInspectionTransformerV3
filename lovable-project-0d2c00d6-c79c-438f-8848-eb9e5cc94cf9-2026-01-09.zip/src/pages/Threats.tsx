import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { ThreatTable } from '@/components/threats/ThreatTable';
import { ThreatFilters } from '@/components/threats/ThreatFilters';
import { StatsCard } from '@/components/dashboard/StatsCard';
import { AlertTriangle, Shield, ShieldAlert, ShieldCheck } from 'lucide-react';
import { ThreatLog, RiskLevel, SourceType } from '@/types';

// Generate mock threat data
const generateMockThreats = (count: number): ThreatLog[] => {
  const sources = [
    'https://malicious-domain.com/payload.exe',
    'https://phishing-site.org/login.html',
    'suspicious_attachment.pdf',
    'ransomware_dropper.docx',
    'https://crypto-miner.xyz/script.js',
    'trojan_installer.msi',
    'https://botnet-c2.net/command',
    'keylogger.dll',
    'https://spam-link.info/redirect',
    'malware_sample.zip',
  ];

  const riskLevels = Object.values(RiskLevel);
  const sourceTypes = Object.values(SourceType);

  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    source: sources[Math.floor(Math.random() * sources.length)],
    source_type: sourceTypes[Math.floor(Math.random() * sourceTypes.length)],
    probability: Math.random() * 0.6 + 0.4,
    bytes_scanned: Math.floor(Math.random() * 50000000),
    risk_level: riskLevels[Math.floor(Math.random() * riskLevels.length)],
    timestamp: new Date(Date.now() - Math.random() * 86400000 * 7).toISOString(),
    blocked: Math.random() > 0.3,
  }));
};

const mockThreats = generateMockThreats(100);

export default function Threats() {
  const [filters, setFilters] = useState({
    risk_level: undefined as string | undefined,
    source_type: undefined as string | undefined,
    limit: 10,
    offset: 0,
  });

  // Filter threats based on current filters
  const filteredThreats = mockThreats.filter((threat) => {
    if (filters.risk_level && threat.risk_level !== filters.risk_level) return false;
    if (filters.source_type && threat.source_type !== filters.source_type) return false;
    return true;
  });

  // Paginate
  const paginatedThreats = filteredThreats.slice(
    filters.offset,
    filters.offset + filters.limit
  );

  const handleFilterChange = (newFilters: Partial<typeof filters>) => {
    setFilters((prev) => ({
      ...prev,
      ...newFilters,
      offset: newFilters.limit !== undefined || newFilters.risk_level !== undefined || newFilters.source_type !== undefined ? 0 : prev.offset,
    }));
  };

  const handlePageChange = (offset: number) => {
    setFilters((prev) => ({ ...prev, offset }));
  };

  // Calculate stats
  const criticalCount = mockThreats.filter((t) => t.risk_level === RiskLevel.CRITICAL).length;
  const highCount = mockThreats.filter((t) => t.risk_level === RiskLevel.HIGH).length;
  const blockedCount = mockThreats.filter((t) => t.blocked).length;

  return (
    <MainLayout
      title="Threat Logs"
      subtitle="View and analyze detected threats"
    >
      {/* Quick stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <StatsCard
          title="Total Threats"
          value={mockThreats.length}
          icon={AlertTriangle}
        />
        <StatsCard
          title="Critical"
          value={criticalCount}
          icon={ShieldAlert}
          variant="danger"
        />
        <StatsCard
          title="High Risk"
          value={highCount}
          icon={Shield}
          variant="warning"
        />
        <StatsCard
          title="Blocked"
          value={blockedCount}
          subtitle={`${((blockedCount / mockThreats.length) * 100).toFixed(1)}% of threats`}
          icon={ShieldCheck}
          variant="success"
        />
      </div>

      {/* Filters */}
      <ThreatFilters filters={filters} onFilterChange={handleFilterChange} />

      {/* Table */}
      <ThreatTable
        threats={paginatedThreats}
        total={filteredThreats.length}
        limit={filters.limit}
        offset={filters.offset}
        onPageChange={handlePageChange}
      />
    </MainLayout>
  );
}
